package com.tiklab.example.test;

public interface TikalbTestService {

    void testaa();


    void testbb();
}
