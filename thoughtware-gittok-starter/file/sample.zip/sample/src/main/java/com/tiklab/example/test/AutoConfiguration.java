package com.tiklab.example.test;


import org.springframework.context.annotation.*;

@Configuration
@ComponentScan(basePackages = {"com.tiklab"})
public class AutoConfiguration {


}
