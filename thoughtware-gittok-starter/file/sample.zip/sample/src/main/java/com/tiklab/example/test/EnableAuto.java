package com.tiklab.example.test;


import org.springframework.context.annotation.Import;
import java.lang.annotation.*;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import({
        AutoConfiguration.class,
})
public @interface EnableAuto {
}
