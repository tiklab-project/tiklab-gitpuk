package com.tiklab.example.test;

public interface TikalbTestService2 {

    void testaa();


    void testbb();
}
