package com.tiklab.example.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TikalbTest2 implements  TikalbTestService {

    @Autowired
    TikalbTestService2 tikalbTestService2;

    @Override
    public void testaa(){
        testbb();
        tikalbTestService2.testaa();
    }



    public void testbb(){
        testaa();
    }


    public void testcc(){
        testaa();
    }


}
