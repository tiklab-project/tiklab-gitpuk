package com.tiklab.example.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TikalbTest implements TikalbTestService2 {

    @Autowired
    TikalbTestService tikalbTest2;

    public void testaa(){
        testbb();
        tikalbTest2.testaa();
    }



    public void testbb(){
        testaa();
    }


    public void testcc(){
        testaa();
    }


}
