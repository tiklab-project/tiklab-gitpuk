package com.tiklab.example;

import com.tiklab.example.test.EnableAuto;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@EnableAuto
@SpringBootApplication
public class TiklabExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(TiklabExampleApplication.class, args);
        System.out.println("helle tiklab！");
    }


    public void testaa(){
        testbb();
    }



    public void testbb(){
        testaa();
    }


    public void testcc(){
        testaa();
    }

}
