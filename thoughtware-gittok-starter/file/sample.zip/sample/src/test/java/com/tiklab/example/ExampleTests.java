package com.tiklab.example;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ExampleTests {

    @Test
    public void contextLoadsTest() {
        System.out.println("这是一个测试用例！");
    }

}
